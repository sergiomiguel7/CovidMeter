package com.example.covidmeter.views;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.covidmeter.MainActivity;
import com.example.covidmeter.R;
import com.example.covidmeter.controllers.SessionController;
import com.example.covidmeter.models.Info;
import com.example.covidmeter.models.User;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;


/**
 * A simple {@link Fragment} subclass.
 */
public class HomeScreenFragment extends Fragment {

    private User user;
    private List<String> infoStates;


    public HomeScreenFragment(User user) {
        this.user = user;
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home_screen, container, false);
        TextView welcome_text = view.findViewById(R.id.welcome_text);
        TextView location_text = view.findViewById(R.id.location_text);
        TextView symptoms_text = view.findViewById(R.id.nmr_symptoms_text);
        TextView state_text = view.findViewById(R.id.state_text_home);
        RecyclerView recyclerView = view.findViewById(R.id.infoRecycler);
        infoStates = new ArrayList<>(Arrays.asList(getResources().getStringArray(R.array.Info_texts)));


        String welcome = "Olá " + this.user.getName() + "!";
        welcome_text.setText(welcome);
        location_text.setText(this.user.getLocation());
        state_text.setText(this.user.getHealthState().getState());

        if (user.getHealthState().getSymptoms().get(0).getName().equals("Sem sintomas"))
            symptoms_text.setText(R.string.zero_symptoms_info_text);
        else {
            String symtomsNumber = String.format(Locale.getDefault(), "%d sintoma(s)", this.user.getHealthState().getSymptoms().size());
            symptoms_text.setText(symtomsNumber);
        }

        HomeScreenFragment.InfoListAdapter recyclerViewAdapter = new HomeScreenFragment.InfoListAdapter();
        RecyclerView.LayoutManager layoutManager = new GridLayoutManager(MainActivity.getContext(), 2);


        recyclerView.setAdapter(recyclerViewAdapter);
        recyclerView.setLayoutManager(layoutManager);

        return view;
    }

    public void callUpdateFragment(View view){

    }

    class InfoListAdapter extends RecyclerView.Adapter<HomeScreenFragment.InfoListAdapter.SymptomViewHolder> {

        private int[] images = {R.drawable.semsintomas, R.drawable.comsintomas,R.drawable.suspeitos, R.drawable.infetados};
        private List<Info> infoList;

        public InfoListAdapter() {
            infoList = SessionController.getInstance().getInformation().getValue();
        }


        @NonNull
        @Override
        public HomeScreenFragment.InfoListAdapter.SymptomViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            LayoutInflater inflater = LayoutInflater.from(MainActivity.getContext());
            View itemView = inflater.inflate(R.layout.info_item, parent, false);
            return new HomeScreenFragment.InfoListAdapter.SymptomViewHolder(itemView);
        }

        @Override
        public void onBindViewHolder(@NonNull final HomeScreenFragment.InfoListAdapter.SymptomViewHolder holder, final int position) {
            holder.typePhoto.setBackgroundResource(images[position]);
            holder.infoNumber.setText(String.valueOf(infoList.get(position).getQtdInfo()));
            holder.infoType.setText(infoList.get(position).getTypeInfo());
        }


        @Override
        public int getItemCount() {
            return infoStates.size();
        }

        class SymptomViewHolder extends RecyclerView.ViewHolder {

            ImageView typePhoto;
            TextView infoNumber, infoType;

            public SymptomViewHolder(@NonNull View itemView) {
                super(itemView);
                typePhoto=itemView.findViewById(R.id.type_photo);
                infoNumber = itemView.findViewById(R.id.info_number);
                infoType = itemView.findViewById(R.id.info_type);
            }
        }


    }

}
