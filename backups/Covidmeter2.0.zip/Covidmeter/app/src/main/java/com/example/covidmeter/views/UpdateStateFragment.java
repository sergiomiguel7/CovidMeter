package com.example.covidmeter.views;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.example.covidmeter.MainActivity;
import com.example.covidmeter.R;
import com.example.covidmeter.controllers.SessionController;
import com.example.covidmeter.models.Symptom;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 */
public class UpdateStateFragment extends Fragment {

    private List<Symptom> symptomsList, selectedSymptoms;
    private String state;
    private RadioGroup radioGroup;
    private Button button;

    public UpdateStateFragment(List<Symptom> symptoms) {
        this.symptomsList = symptoms;
        this.selectedSymptoms = new ArrayList<>();
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_update_state, container, false);
        RecyclerView recyclerView = view.findViewById(R.id.symptomsRecycler);
        button = view.findViewById(R.id.confirm_button);
        radioGroup= view.findViewById(R.id.radio_group);

        handleRadioGroup();

        SymptomsListAdapter recyclerViewAdapter = new SymptomsListAdapter();
        RecyclerView.LayoutManager layoutManager = new GridLayoutManager(MainActivity.getContext(), 2);


        recyclerView.setAdapter(recyclerViewAdapter);
        recyclerView.setLayoutManager(layoutManager);

        return view;
    }


    /*
    in this method create a radio group with the options available in the string.xml referent to the state of user
    including the onClickListener to check if a option was selected
     */
    private void handleRadioGroup() {
        List<String> stateList = new ArrayList<>(Arrays.asList(getResources().getStringArray(R.array.List_choices)));
        int i =0;
        for(final String state : stateList){
            RadioButton radioButton = new RadioButton(MainActivity.getContext());
            radioButton.setText(state);
            radioButton.setId(i);
            radioButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    boolean checked = ((RadioButton) v).isChecked();

                    if(checked){
                        updateState(state);
                    }
                }
            });
            this.radioGroup.addView(radioButton);
            i++;
        }
    }

    private void updateState(String state){
        this.state=state;
    }

    /*
    when the user clicks the confirm button it checks everything and update the user state(SessionController)
     */
    public void updateUserSymptoms(View view) {
        if (selectedSymptoms.size() > 0 && state !=null) {
            SessionController.getInstance().updateUserState(selectedSymptoms, state);
            button.setVisibility(View.INVISIBLE);
        }
        else
            Toast.makeText(MainActivity.getContext(), "Nenhuma opção selecionada", Toast.LENGTH_SHORT).show();
    }


    class SymptomsListAdapter extends RecyclerView.Adapter<SymptomsListAdapter.SymptomViewHolder> {


        public SymptomsListAdapter() {
        }


        @NonNull
        @Override
        public SymptomViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            LayoutInflater inflater = LayoutInflater.from(MainActivity.getContext());
            View itemView = inflater.inflate(R.layout.symptom_item, parent, false);
            return new SymptomViewHolder(itemView);
        }

        @Override
        public void onBindViewHolder(@NonNull final SymptomViewHolder holder, final int position) {
            holder.symptom_name.setText(symptomsList.get(position).getName());

            //todo: se o sem sintomas estiver selecionado, tirar os outros todos
            /*
            if the checkbox was selected the symptom is added to a list where the user saves is information
             */
            holder.checkBox.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    final boolean isChecked = holder.checkBox.isChecked();
                    for (int i = 0; i < symptomsList.size(); i++) {
                        if (isChecked) {
                            if (!selectedSymptoms.contains(symptomsList.get(position)))
                                selectedSymptoms.add(i, symptomsList.get(position));
                        } else {
                            selectedSymptoms.remove(symptomsList.get(position));
                        }
                    }
                }
            });

        }


        @Override
        public int getItemCount() {
            return symptomsList.size();
        }

        class SymptomViewHolder extends RecyclerView.ViewHolder {

            TextView symptom_name;
            CheckBox checkBox;

            public SymptomViewHolder(@NonNull View itemView) {
                super(itemView);
                symptom_name = itemView.findViewById(R.id.symptom_name);
                checkBox = itemView.findViewById(R.id.checkbox);
            }
        }


    }
}
